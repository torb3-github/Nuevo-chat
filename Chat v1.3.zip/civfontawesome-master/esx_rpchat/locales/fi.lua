Locales['fi'] = {
	['ooc_help'] = 'kirjota hahmon ulkopuolelle liittyvä viesti',
	['ooc_prefix'] = 'OOC | %s',
	['twt_help'] = 'lähetä twiitti',
	['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
	['me_help'] = 'teet jotain',
	['me_prefix'] = 'me | %s',
	['do_help'] = 'roolipeliä tiedot', --TODO: check translation
	['do_prefix'] = 'do | %s',
	['news_help'] = 'ilmoita uutinen (älä abuse)',
	['news_prefix'] = 'news | %s',
	['ooc_argument_name'] = 'viesti',
	['ooc_argument_help'] = 'viestin sisältö',
	['ooc_unknown_command'] = '^3%s^0 ei ole validi komento!',
}

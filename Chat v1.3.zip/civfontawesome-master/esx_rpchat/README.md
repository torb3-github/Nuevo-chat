# esx_rpchat
FXServer ESX RP Chat


#### Description
This is a proximity chat script. With a few commands such as Twitter, OOC, Local Me, and Local Do.

#### Requirements
- [esx_identity](https://github.com/ESX-Org/esx_identity)

#### Download

**1) Using [fvm](https://github.com/qlaffont/fvm-installer)**
```
fvm install --save --folder=esx esx-org/esx_rpchat
```

**2) Manually**
- Download https://github.com/ESX-Org/esx_rpchat/releases/latest
- Put it in resource/[esx] directory

**3) Using Git**

```
cd resouces
git clone https://github.com/ESX-Org/esx_rpchat
```

#### Installation

1) Add `start esx_rpchat` to your server.cfg
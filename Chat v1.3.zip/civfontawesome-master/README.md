# civfontawesome by KrizFrost
This was released publically due to me closing my server and other means 
You have permission to edit this but do not re release it please. 

# Dependency
You will need the most updated version of chat
Located here 
https://github.com/citizenfx/cfx-server-data 

# Instructions
You need to start the resources in this order

- start chat
- start chat-theme-civlifechat
- start esx_rpchat
